package org.example.ui;

import com.vaadin.ui.Component;

public class MyUIPresenter {

  private MyUIView myUIView;

  public MyUIPresenter() {
    myUIView = new MyUIViewImpl();
  }

  public void addComponentToUILayout1(Component component) {
    myUIView.addComponentToUILayout1(component);
  }

  public void addComponentToMapLayout(Component component, String position) {
    myUIView.addComponentToMapLayout(component, position);
  }

  public void addComponentToMapVerticalLayout(Component component) {
    myUIView.addComponentToMapVerticalLayout(component);
  }

  public Component getView() {
    return (Component) this.myUIView;
  }

}
