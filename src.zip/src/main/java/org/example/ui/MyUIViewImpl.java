package org.example.ui;


import com.vaadin.ui.Component;

public class MyUIViewImpl extends MyUIDesign implements MyUIView {


  @Override
  public void addComponentToUILayout1(Component component) {
    uiLayout1.addComponent(component);
  }

  @Override
  public void addComponentToMapVerticalLayout(Component component) {
    mapLayout.addComponent(component);
  }

  @Override
  public void addComponentToMapLayout(Component component, String position) {
//    mapLayout.addComponent(component,position);
  }

}
