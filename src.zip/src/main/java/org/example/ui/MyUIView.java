package org.example.ui;


import com.vaadin.ui.Component;

public interface MyUIView {

  void addComponentToUILayout1(Component component);

  void addComponentToMapLayout(Component component,String position);

  void addComponentToMapVerticalLayout(Component component);
}
