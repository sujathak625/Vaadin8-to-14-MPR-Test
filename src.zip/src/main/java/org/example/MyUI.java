package org.example;

import com.vaadin.annotations.Theme;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.router.Route;
import com.vaadin.mpr.core.HasLegacyComponents;
import com.vaadin.ui.Button;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextField;
import org.example.ui.MyUIPresenter;
import org.vaadin.addon.leaflet.LFeatureGroup;
import org.vaadin.addon.leaflet.LMap;
import org.vaadin.addon.leaflet.LOpenStreetMapLayer;
import org.vaadin.addon.leaflet.LTileLayer;
import org.vaadin.addon.leaflet.LeafletLayer;

//This UI is the application entry point. A UI may either represent a browser window (or tab) or
// some part of an HTML page where a Vaadin application is embedded.
//<p>
// The UI is initialized using . This method is intended to be overridden to add component to the
// user interface and initialize non-component functionality.

@Theme("mytheme")
@Route("")
public class MyUI extends Div implements HasLegacyComponents {

  private LTileLayer osmTiles = new LOpenStreetMapLayer();
  private MyUIPresenter myUIPresenter;
  LMap map = new LMap();
  private LFeatureGroup lfg = new LFeatureGroup();
  ;
  LeafletLayer leafletLayer;


  public MyUI() {

    myUIPresenter = new MyUIPresenter();
    final TextField mapText = new TextField();
    mapText.setCaption("Map component");
    map.addBaseLayer(osmTiles, "OSM");
    map.setCenter(51.18641111764806, 10.428327809551346);
    map.setZoomLevel(5);
  /*  myUIPresenter.addComponentToMapLayout(mapText, "left: 30px; top: 50px;");
    //  myUIPresenter.addComponentToMapLayout(map, "z-index: 0");*/
    myUIPresenter.addComponentToMapVerticalLayout(mapText);
    myUIPresenter.addComponentToMapVerticalLayout(map);
    final TextField name = new TextField();
    name.setCaption("Type your name here:");
    myUIPresenter.addComponentToUILayout1(name);
    Button button = new Button("Click Me");
    myUIPresenter.addComponentToUILayout1(button);
    button.addClickListener(e -> {
      Notification.show("Good " + name.getValue() + ". This works");
    });
    add(myUIPresenter.getView());
  }

}

//vaadin 8
/*import com.vaadin.annotations.VaadinServletConfiguration;
    import com.vaadin.server.VaadinRequest;
    import com.vaadin.server.VaadinServlet;
    import com.vaadin.ui.Button;
    import com.vaadin.ui.Notification;
    import com.vaadin.ui.TextField;
    import com.vaadin.ui.UI;
    import javax.servlet.annotation.WebServlet;
    import org.example.ui.MyUIPresenter;
    import org.vaadin.addon.leaflet.LFeatureGroup;
    import org.vaadin.addon.leaflet.LMap;
    import org.vaadin.addon.leaflet.LOpenStreetMapLayer;
    import org.vaadin.addon.leaflet.LTileLayer;
    import org.vaadin.addon.leaflet.LeafletLayer;


public class MyUI extends UI {

  private LTileLayer osmTiles = new LOpenStreetMapLayer();
  private MyUIPresenter myUIPresenter;
  LMap map = new LMap();
  private LFeatureGroup lfg = new LFeatureGroup();
  ;
  LeafletLayer leafletLayer;

  protected void init(VaadinRequest vaadinRequest) {

    myUIPresenter = new MyUIPresenter();
    final TextField mapText = new TextField();
    mapText.setCaption("Map component");
    map.addBaseLayer(osmTiles, "OSM");
    map.setCenter(51.18641111764806, 10.428327809551346);
    map.setZoomLevel(5);
   *//* myUIPresenter.addComponentToMapVerticalLayout(mapText, "left: 30px; top: 50px;");
    myUIPresenter.addComponentToMapVerticalLayout(map, "z-index: 0");*//*
    myUIPresenter.addComponentToMapVerticalLayout(mapText);
    myUIPresenter.addComponentToMapVerticalLayout(map);
    final TextField name = new TextField();
    name.setCaption("Type your name here:");
    myUIPresenter.addComponentToUILayout1(name);
    Button button = new Button("Click Me");
    myUIPresenter.addComponentToUILayout1(button);
    button.addClickListener(e -> {
      Notification.show("Good " + name.getValue() + ". This works");
    });

    setContent(myUIPresenter.getView());

  }

  @WebServlet(urlPatterns = "/*", name = "MyUIServlet", asyncSupported = true)
  @VaadinServletConfiguration(ui = MyUI.class, productionMode = false)
  public static class MyUIServlet extends VaadinServlet {

  }
}*/
